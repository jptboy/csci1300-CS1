// Author: Ayush Khanal CS1300 Fall 2017
// Recitation: 204- Chelsea Chandler
// Cloud9 Workspace Editor Link: https://ide.c9.io/ayushkhanal/ayushkhanalcsci1300
// Recitation 6 - Problem # 1
#include <iostream>
using namespace std;
/*
Algorithim: No algorithim 
*/
int main()
{
    int arrayOne[49];//are comments necessary? all I did was create arrays that held different data types and intiialized their length
    float arrayTwo[4];
    bool arrayTri[14];
    string arrayFor[12];
    return 0;
}